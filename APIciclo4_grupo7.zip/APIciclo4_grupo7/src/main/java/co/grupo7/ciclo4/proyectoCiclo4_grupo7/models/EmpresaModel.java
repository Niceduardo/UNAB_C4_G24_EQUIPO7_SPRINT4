package co.grupo7.ciclo4.proyectoCiclo4_grupo7.models;

public class EmpresaModel {

    private String nombreE;
    private String ciudadE;
    
    public EmpresaModel() {
    }

    public EmpresaModel(String nombreE, String ciudadE) {
        this.nombreE = nombreE;
        this.ciudadE = ciudadE;
    }

    public String getNombreE() {
        return nombreE;
    }

    public void setNombreE(String nombreE) {
        this.nombreE = nombreE;
    }

    public String getCiudadE() {
        return ciudadE;
    }

    public void setCiudadE(String ciudadE) {
        this.ciudadE = ciudadE;
    }

}
