package co.grupo7.ciclo4.proyectoCiclo4_grupo7.repositories;

import java.time.LocalDate;
import java.util.ArrayList;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import co.grupo7.ciclo4.proyectoCiclo4_grupo7.models.ProductoModel;

@Repository
public interface ProductoRepository extends MongoRepository<ProductoModel, String>{
 
    ArrayList<ProductoModel> findByNombre(String nombre);
    ArrayList<ProductoModel> findByColor(String color);
    ArrayList<ProductoModel> findByFechaRegistro(LocalDate fechaRegistro);

}
